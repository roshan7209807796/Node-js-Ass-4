
exports.getAddition = (req, res, next) => {
    const num1 = req.body.num1;
    const num2 = req.body.num2;
}
const router = require('express').Router();


router.get('/', (req, res) => {
    res.send(` <h1> this is multiply homepage </h1> `);
    console.log('multiply function running');
})

router.post('/', (req, res) => {
    // console.log(req.body);
    let num1 = req.body.num1;
    let num2 = req.body.num2;

    if (typeof num1 == "string" || typeof num2 == "string") return res.send("invalid datatype");

    let product = Number(num1) * Number(num2);
    console.log(`the product is ${product}`);
    res.send(`The product is equal to ${product}`);
})


module.exports = router;
const router = require('express').Router();

router.get('/', (req, res) => {
    res.send(`<h1> this is sub homepage </h1>`);
    console.log('sub function running');
})

router.post('/', (req, res) => {
    // console.log(req.body);
    let num1 = req.body.num1;
    let num2 = req.body.num2;

    if (typeof num1 == "string" || typeof num2 == "string") return res.send("invalid datatype");

    let subtraction = Number(num1) - Number(num2);
    console.log(`the subtraction is ${subtraction}`);
    res.send(`The subtraction is equal to ${subtraction}`);
})


module.exports = router;
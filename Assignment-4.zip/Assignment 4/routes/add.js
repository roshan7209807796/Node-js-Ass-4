const router = require('express').Router();


router.get('/', (req, res) => {
    res.send(`<h1> this is add homepage </h1>`);
    console.log('add function running');
})

router.post('/', (req, res) => {
    // console.log(req.body);
    let num1 = req.body.num1;
    let num2 = req.body.num2;

    let sum = num1 + num2;
    typeof sum == "string" ?
        res.send(`invalid datatype`) :
        res.send(`The sum is equal to ${sum}`);

    typeof sum == "string" ?
        console.log(`invalid datatype`) :
        console.log(`the sum is ${sum}`);
})


module.exports = router;
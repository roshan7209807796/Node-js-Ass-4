const router = require("express").Router();

router.get("/", (req, res) => {
    console.log(` <h1> division function is running </h1>`);
    res.send("this is divide homepage");
});

router.post("/", (req, res) => {
    // console.log(req.body);
    let num1 = req.body.num1;
    let num2 = req.body.num2;

    let division = num1 / num2;
    if (typeof num1 == "string" || typeof num2 == "string") return res.send("invalid datatype");

    if (num2 == 0) {
        res.send(`Cannot divide a number by 0`);
        console.log("cannot divide a number by 0")
    }
    else {
        res.send(`The division is equal to ${division}`);
        console.log(`the division is ${division}`);
    }
});

module.exports = router;



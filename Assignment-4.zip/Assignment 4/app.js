const express = require('express');
const app = express();

//router imports
const addRoute = require('./routes/add');
const divideRoute = require('./routes/divide');
const multiplyRoute = require('./routes/multiply');
const subRoute = require('./routes/sub');


app.use(express.json());


let port = process.env.PORT || 3000;

app.get('/', (req, res) => {
    res.send('<h1> Hello World!! </h1>');
    console.log('Hello World!!');
})

// addition 
app.use('/add', addRoute);

// divide 
app.use('/divide', divideRoute);


// multiply
app.use('/multiply', multiplyRoute);

//subtraction
app.use('/sub', subRoute);

app.listen(port, () => {
    console.log(`App is running at port: ${port}....`);
})